package coursemanagementsystem;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
public class CourseManagementSystem extends JFrame {
    public CourseManagementSystem(){
    super("COURSE MANAGEMENT SYSTEM LOGIN PAGE");
    JPanel p=new JPanel(null);
    p.setBounds(20, 20, 400,320);
    p.setBackground(Color.green);
    JLabel jla,jlb;
    jla=new JLabel("USER NAME");
    jla.setBounds(20, 100, 80, 30);
    p.add(jla);
    jlb=new JLabel("PASSWORD");
    jlb.setBounds(20, 140,80, 30);
    p.add(jlb);
   final JTextField jtf=new JTextField("habtamu");
   jtf.setBounds(140,100, 160, 30);
   p.add(jtf);
   final JPasswordField jpf=new JPasswordField("0701834");
   jpf.setBounds(140, 140, 160, 30);
   p.add(jpf);
   final JLabel jl=new JLabel();
   p.add(jl);
   jl.setBounds(20, 50, 370, 30);
   JButton jb=new JButton("LOGIN");
   jb.setBounds(150, 250, 70, 30);
   jb.addActionListener(new ActionListener(){
   @Override
   public void actionPerformed(ActionEvent ae){
       if(jtf.getText().equals("habtamu")&&jpf.getText().equals("0701834")){
 HomePage hp=new HomePage();
 hp.setSize(1200, 700);
 hp.setLayout(null);
 hp.setDefaultCloseOperation(3);
 hp.setVisible(true);
       setVisible(false);
       }
       else{
     jl.setText("INCORRECT USER NAME AND PASSWORD PLEASE TRY AGAIN!");
       jtf.setText("USER NAME");
       jpf.setText("PASSWORD");
       }
   }
   });
   p.add(jb);
    add(p);
    } 
    public static void main(String[] args) {
      CourseManagementSystem cms=new CourseManagementSystem();
      cms.setSize(450, 400);
      cms.setLayout(null);
      cms.setDefaultCloseOperation(3);
      cms.setVisible(true);
 }
}


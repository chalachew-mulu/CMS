
package coursemanagementsystem;
import java.awt.Color;
import javax.swing.*;
public class Help extends JFrame{
    public Help(){
    super("HELP FRAME");
    JLabel lb1=new JLabel("first confirm whether you want to assign course for the teacher");
   JLabel lb2=new JLabel("by selecting the radio button");
   JLabel lb3=new JLabel("then select the teacher from the list");
   JLabel lb4=new JLabel("next select the course from the list");
   JLabel lb5=new JLabel("finally press ASSIGN button");
   lb1.setBounds(10, 20, 600, 30);
   lb2.setBounds(10, 60, 600, 30);
   lb3.setBounds(10, 100, 600, 30);
   lb4.setBounds(10, 140, 600, 30);
   lb5.setBounds(10, 180, 600, 30);
   add(lb1);
      add(lb2);
         add(lb3);
            add(lb4);
               add(lb5);
    }
    
}

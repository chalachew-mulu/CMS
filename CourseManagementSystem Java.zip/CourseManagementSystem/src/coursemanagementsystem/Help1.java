package coursemanagementsystem;
import java.awt.Color;
import javax.swing.*;
public class Help1 extends JFrame{
    public Help1(){
    super("HELP FRAME");
    JLabel lb1=new JLabel("first confirm whether you want to add course for the student");
   JLabel lb2=new JLabel("by selecting the radio button");
   JLabel lb3=new JLabel("then select the student from the list");
   JLabel lb4=new JLabel("next select the course from the list");
   JLabel lb5=new JLabel("finally press ADD button");
   lb1.setBounds(10, 20, 600, 30);
   lb2.setBounds(10, 60, 600, 30);
   lb3.setBounds(10, 100, 600, 30);
   lb4.setBounds(10, 140, 600, 30);
   lb5.setBounds(10, 180, 600, 30);
   add(lb1);
      add(lb2);
         add(lb3);
            add(lb4);
               add(lb5);
    }
    
}
package coursemanagementsystem;
import java.awt.Container;
import java.awt.Color;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class HomePage extends JFrame {
DefaultListModel<String> lmstud = new DefaultListModel<String>();
DefaultListModel<String> lmcourse = new DefaultListModel<String>();
private final JList liststud=new JList(lmstud);
private final JList listcourse=new JList(lmcourse);
private final ArrayList<Student> sarray=new ArrayList();
private final ArrayList<Teacher> tarray=new ArrayList();
private final ArrayList<Course> carray=new ArrayList();
 public HomePage(){
 super("COURSE MANAGEMENT SYSTEM HOMEPAGE");
 final JInternalFrame registerStudent,registerTeacher,registerCourse,search,display,assign,add;
 assign=new JInternalFrame("ASSIGN COURSE",true,true,true,true);
 assign.setBounds(10, 170, 970, 440);
 add(assign);
  add=new JInternalFrame("ADD COURSE",true,true,true,true);
  add.setBounds(10, 170, 970, 440);
 add(add);
 display=new JInternalFrame("DISPLAY DATA",true,true,true,true);
 display.setBounds(100, 230, 700, 300);
 add(display);
 search=new JInternalFrame("SEARCH DATA",true,true,true,true);
 search.setBounds(100, 180, 700, 300);
 add(search);
 registerStudent=new JInternalFrame("REGISTER STUDENT",true,true,true,true);
 registerStudent.setBounds(100, 140, 300, 300);
 registerTeacher=new JInternalFrame("REGISTER TEACHER",true,true,true,true);
 registerTeacher.setBounds(300, 140, 300, 300);
 registerCourse=new JInternalFrame("REGISTER COURSE",true,true,true,true);
registerCourse.setBounds(500, 140, 300, 300);
 add(registerStudent);
 add(registerTeacher);
 add(registerCourse);
 JPanel pw,pr,ps,pi; 
 pw=new JPanel(null);
 pw.setBounds(20, 20, 1000, 40);
 pw.setBackground(Color.pink);
 JLabel lb=new JLabel("WELL COME TO COURSE MANAGEMENT SYSTEM OF SOFTWARE ENGINEERING DEPARTMENT");
 lb.setBounds(20, 5, 540, 30);
 pw.add(lb);
 add(pw);
 pr=new JPanel(null);
 pr.setBounds(150,70, 750, 100);
 pr.setBackground(Color.blue);
 JButton rs,rt,rc,ss,st,sc;
 rs=new JButton("REGISTER STUDENT");
 rs.setBounds(20, 30, 160, 40);
 rs.addActionListener(new ActionListener(){
     @Override
     public void actionPerformed(ActionEvent ae){
 Container panel=registerStudent.getContentPane();
 panel.setLayout(null);
panel.removeAll();
final JLabel lb1=new JLabel("NAME");
final JLabel lb2=new JLabel("ID");
final JLabel lb3=new JLabel("BIRTHDATE");
final JLabel lb4=new JLabel("AGE");
final JLabel lb5=new JLabel("SEX");
final JLabel lb6=new JLabel("YEAR");
 lb1.setBounds(10,10,100,30);
                lb2.setBounds(10,40,100,30);
                lb3.setBounds(10,70,100,30);
                lb4.setBounds(10,100,100,30);
                lb5.setBounds(10,130,100,30);
                lb6.setBounds(10,160,100,30);

                panel.add(lb1);
                panel.add(lb2);
                panel.add(lb3);
                panel.add(lb4);
                panel.add(lb5);
                panel.add(lb6);
                final JTextField tf1=new JTextField("");
                final JTextField tf2=new JTextField("");
                final JTextField tf3=new JTextField("");
                final JTextField tf4=new JTextField("");
                final JComboBox tf5=new JComboBox(new String []{"Male","Female"});
                final JTextField tf6=new JTextField("");

                tf1.setBounds(110,10,150,30);
                tf2.setBounds(110,40,150,30);
                tf3.setBounds(110,70,150,30);
                tf4.setBounds(110,100,150,30);
                tf5.setBounds(110,130,150,30);
                tf6.setBounds(110,160,150,30);

                panel.add(tf1);
                panel.add(tf2);
                panel.add(tf3);
                panel.add(tf4);
                panel.add(tf5);
                panel.add(tf6);
                JButton btnSave=new JButton("SAVE");
                btnSave.setBounds(100,200,100,30);
                btnSave.addActionListener(new ActionListener(){

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Student stud=new Student();
                        stud.setName(tf1.getText());
                        stud.setId(tf2.getText());
                        stud.setBirthDate(tf3.getText());
                        stud.setAge(Integer.valueOf(tf4.getText()));
                        stud.setSex(tf5.getSelectedItem().toString());
                        stud.setYear(Integer.valueOf(tf6.getText()));
                        sarray.add(stud);
                        File f=new File("studentlist.txt");
                        try{
                        FileOutputStream fos=new FileOutputStream(f,true);
                        fos.write((tf1.getText()+"\t"+tf2.getText()+"\t"+tf3.getText()+"\t"+Integer.valueOf(tf4.getText())+"\t"+tf5.getSelectedItem().toString()+"\t"+Integer.valueOf(tf6.getText())+"\n").getBytes());
                        fos.close();
                        }
                        catch(FileNotFoundException ex){

                        } catch (IOException ex) {
                        }
                        tf1.setText(null);
                         tf2.setText(null);
                          tf3.setText(null);
                           tf4.setText(null);
                            tf6.setText(null);
                    }

                });

                panel.add(btnSave);
                
                registerStudent.setResizable(false);
registerStudent.setClosable(true);
 registerStudent.setVisible(true);
 registerTeacher.setVisible(false);
 registerCourse.setVisible(false);
     }
 });
 pr.add(rs);
 rt=new JButton("REGISTER TEACHER");
 rt.setBounds(240, 30, 160, 40);
  rt.addActionListener(new ActionListener(){
     @Override
     public void actionPerformed(ActionEvent ae){
 Container panel=registerTeacher.getContentPane();
  panel.setLayout(null);
 panel.removeAll();
 final JLabel la1=new JLabel("Name");
                final JLabel la2=new JLabel("ID");
                final JLabel la3=new JLabel("ACCADEMIC RANK");
                final JLabel la4=new JLabel("AGE");
                final JLabel la5=new JLabel("SEX");
                final JLabel la6=new JLabel("SALARY");


                la1.setBounds(10,10,100,30);
                la2.setBounds(10,40,100,30);
                la3.setBounds(10,70,100,30);
                la4.setBounds(10,100,100,30);
                la5.setBounds(10,130,100,30);
                la6.setBounds(10,160,100,30);

                panel.add(la1);
                panel.add(la2);
                panel.add(la3);
                panel.add(la4);
                panel.add(la5);
                panel.add(la6);

                final JTextField txt1=new JTextField("");
                final JTextField txt2=new JTextField("");
                final JComboBox txt3=new JComboBox(new String []{"BSC","MSC","PHD","PROFESSOR"});
                final JTextField txt4=new JTextField("");
                final JComboBox txt5=new JComboBox(new String []{"Male","Female"});
                final JTextField txt6=new JTextField("");

                txt1.setBounds(110,10,150,30);
                txt2.setBounds(110,40,150,30);
                txt3.setBounds(110,70,150,30);
                txt4.setBounds(110,100,150,30);
                txt5.setBounds(110,130,150,30);
                txt6.setBounds(110,160,150,30);

                panel.add(txt1);
                panel.add(txt2);
                panel.add(txt3);
                panel.add(txt4);
                panel.add(txt5);
                panel.add(txt6);
                JButton btnSave=new JButton("SAVE");
                btnSave.setBounds(100,200,100,30);
                btnSave.addActionListener(new ActionListener(){

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Teacher teach=new Teacher();
                        teach.setName(txt1.getText());
                        teach.setId(txt2.getText());
                        teach.setARank(txt3.getSelectedItem().toString());
                        teach.setAge(Integer.valueOf(txt4.getText()));
                        teach.setSex(txt5.getSelectedItem().toString());
                        teach.setSalary(Double.valueOf(txt6.getText()));
                        tarray.add(teach);
                        File f=new File("teacherlist.txt");
                        try{
                        FileOutputStream fos=new FileOutputStream(f,true);
                        fos.write((txt1.getText()+"\t"+txt2.getText()+"\t"+txt3.getSelectedItem()+"\t"+Integer.valueOf(txt4.getText())+"\t"+txt5.getSelectedItem().toString()+"\t"+Double.valueOf(txt6.getText())+"\n").getBytes());
                        fos.close();
                        }
                        catch(FileNotFoundException ex){

                        } catch (IOException ex) {
                        }
                        txt1.setText(null);
                        txt2.setText(null);
                        txt4.setText(null);
                        txt6.setText(null);
                    }

                });

                panel.add(btnSave);
 registerTeacher.setVisible(true);
 registerStudent.setVisible(false);
 registerCourse.setVisible(false);
 registerTeacher.setClosable(true);
registerTeacher.setResizable(false);
 
     }
 });
 pr.add(rt);
 rc=new JButton("REGISTER COURSE");
 rc.setBounds(460, 30, 160, 40);
  rc.addActionListener(new ActionListener(){
     @Override
     public void actionPerformed(ActionEvent ae){
 Container panel=registerCourse.getContentPane();
 panel.setLayout(null);
 panel.removeAll();
 final JLabel lal1=new JLabel("COURSE TITLE");
                final JLabel lal2=new JLabel("COURSE CODE");
                final JLabel lal3=new JLabel("CREDIT HOUR");
                final JLabel lal4=new JLabel("DESCRIPTION");


                lal1.setBounds(10,10,100,30);
                lal2.setBounds(10,40,100,30);
                lal3.setBounds(10,70,100,30);
                lal4.setBounds(10,100,100,30);

                panel.add(lal1);
                panel.add(lal2);
                panel.add(lal3);
                panel.add(lal4);

                final JTextField txf1=new JTextField("");
                final JTextField txf2=new JTextField("");
                final JTextField txf3=new JTextField("");
                final JTextField txf4=new JTextField("");

                txf1.setBounds(110,10,150,30);
                txf2.setBounds(110,40,150,30);
                txf3.setBounds(110,70,150,30);
                txf4.setBounds(110,100,150,30);

                panel.add(txf1);
                panel.add(txf2);
                panel.add(txf3);
                panel.add(txf4);
                JButton btnSave=new JButton("SAVE");
                btnSave.setBounds(100,200,100,30);
                btnSave.addActionListener(new ActionListener(){

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Course c=new Course();
                        c.setTitle(txf1.getText());
                        c.setCCode(txf2.getText());
                        c.setCHour(Integer.valueOf(txf3.getText()));
                        c.setCDescription(txf4.getText());
                        carray.add(c);
                        File f=new File("courselist.txt");
                        try{
                        FileOutputStream fos=new FileOutputStream(f,true);
                        fos.write((txf1.getText()+"\t"+txf2.getText()+"\t"+Integer.valueOf(txf3.getText())+"\t"+txf4.getText()+"\n").getBytes());
                        fos.close();
                          }
                        catch(FileNotFoundException ex){

                        }
                        catch(IOException ex){

                        }
                        txf1.setText(null);
                        txf2.setText(null);
                        txf3.setText(null);
                        txf4.setText(null);

                    }

                });

                panel.add(btnSave);

 registerCourse.setVisible(true);
  registerTeacher.setVisible(false);
 registerStudent.setVisible(false);
 registerCourse.setClosable(true);
registerCourse.setResizable(false);
     }
 });
 pr.add(rc);
 add(pr);
 ps=new JPanel(null);
 ps.setBounds(980,180, 200, 400);
 ps.setBackground(Color.green);
 ss=new JButton("SEARCH DATA");
 ss.setBounds(20, 30,160, 30);
ss.addActionListener(new ActionListener(){
 @Override
 public void actionPerformed(ActionEvent ae){//rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
  File f=new File("courselist.txt");
                        try{
                        Scanner scan = new Scanner(f);
                    carray.clear();
                    tarray.clear();
                    sarray.clear();
                    while(scan.hasNext()){
                        Course c=new Course();
                        c.setTitle(scan.next());
                        c.setCCode(scan.next());
                        c.setCHour(Integer.valueOf(scan.next()));
                        c.setCDescription(scan.next());
                        carray.add(c);
                          }
                       scan.close();
                        }
                        catch(FileNotFoundException ex){

                        }
                          File f1=new File("teacherlist.txt");
                        try{
                        Scanner scan1 = new Scanner(f1);

                    while(scan1.hasNext()){
                        Teacher te=new Teacher();
                        te.setName(scan1.next());
                        te.setId(scan1.next());
                        te.setARank(scan1.next());
                        te.setAge(Integer.valueOf(scan1.next()));
                        te.setSex(scan1.next());
                        te.setSalary(Double.valueOf(scan1.next()));
                        tarray.add(te);
                          }
                       scan1.close();
                        }
                        catch(FileNotFoundException ex){

                        }
                         File f2=new File("studentlist.txt");
                        try{
                        Scanner scan3 = new Scanner(f2);

                    while(scan3.hasNext()){
                        Student s2=new Student();
                        s2.setName(scan3.next());
                        s2.setId(scan3.next());
                        s2.setBirthDate(scan3.next());
                        s2.setAge(Integer.valueOf(scan3.next()));
                        s2.setSex(scan3.next());
                        s2.setYear(Integer.valueOf(scan3.next()));
                        sarray.add(s2);
                          }
                       scan3.close();
                        }
                        catch(FileNotFoundException ex){

                        }

     Container panel=search.getContentPane();
                panel.setLayout(null);
                panel.removeAll();
                JButton b1=new JButton("STUDENT");
                b1.setBounds(510,20,100,20);
                JButton b2=new JButton("TEACHER");
                b2.setBounds(510,50,100,20);
                JButton b3=new JButton("COURSE");
                b3.setBounds(510,80,100,20);
                final JComboBox cbs=new JComboBox(new String []{"Name","Id"});
                cbs.setBounds(610,20,80,20);
                final JComboBox cbt=new JComboBox(new String []{"Name","Id"});
                cbt.setBounds(610,50,80,20);
                panel.add(cbs);
                panel.add(cbt);
                final JTextArea ta=new JTextArea();
                ta.setBounds(0,0,500,300);
                b3.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int size=carray.size();
                        String input = null,output;
                        ta.setText(null);
                        ta.setEditable(false);
                        output=JOptionPane.showInputDialog(null,input,"Enter Course Name",JOptionPane.INFORMATION_MESSAGE);
                        ta.setText("COURSE TITLE\t"+"COURSE CODE\t"+"CREDIT HOUR\t"+"DESCRIPTION"+"\n");
                        ta.setText(ta.getText()+"_______________________________________________________________________________________"+"\n");
                                                
                        for(int i=0;i<size;i++){
                            if(carray.get(i).getTitle().equals(output)){
                                Course co=carray.get(i);
                                ta.setText(ta.getText()+co.getTitle()+"\t"+co.getCCode()+"\t"+co.getcHour()+"\t"+co.getCDescription()+"\n");
                            }
                        }
                    }

                });
                b2.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(cbt.getSelectedItem().equals("Name")){
                        int size=tarray.size();
                        String input = null,output;
                        ta.setText(null);
                        ta.setEditable(false);
                        output=JOptionPane.showInputDialog(null,input,"Enter Teacher Name",JOptionPane.INFORMATION_MESSAGE);
                        ta.setText("NAME\t"+"ID\t"+"RANK\t"+"AGE\t"+"SEX\t"+"SALARY"+"\n");
                        ta.setText(ta.getText()+"__________________________________________________________________________________________________________________________"+"\n");
                                                
                        for(int i=0;i<size;i++){
                            if(tarray.get(i).getName().equals(output)){
                                Teacher t=tarray.get(i);
                                ta.setText(ta.getText()+t.getName()+"\t"+t.getId()+"\t"+t.getARank()+"\t"+t.getAge()+"\t"+t.getSex()+"\t"+t.getSalary()+"\n");
                            }
                        }
                        }


                        else if(cbt.getSelectedItem().equals("Id"))
                        {
                        int size=tarray.size();
                        String input = null,output;
                        ta.setText(null);
                        ta.setEditable(false);
                        output=JOptionPane.showInputDialog(null,input,"Enter Teacher Id",JOptionPane.INFORMATION_MESSAGE);
                        ta.setText("NAME\t"+"ID\t"+"ACC RANK\t"+"AGE\t"+"SEX\t"+"SALARY"+"\n");
                        ta.setText(ta.getText()+"__________________________________________________________________________________________________________________________"+"\n");
                                                
                        for(int i=0;i<size;i++){
                            if(tarray.get(i).getId().equals(output)){
                                Teacher t=tarray.get(i);
                                ta.setText(ta.getText()+t.getName()+"\t"+t.getId()+"\t"+t.getARank()+"\t"+t.getAge()+"\t"+t.getSex()+"\t"+t.getSalary()+"\n");
                            }
                        }
                        }


                    }

                });
                 b1.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if(cbs.getSelectedItem().equals("Name")){
                        int size=sarray.size();
                        String input = null,output;
                        ta.setText(null);
                        ta.setEditable(false);
                        output=JOptionPane.showInputDialog(null,input,"Enter Student Name",JOptionPane.INFORMATION_MESSAGE);
                        ta.setText("NAME\t"+"ID\t"+"DEPARTMENT\t"+"AGE\t"+"SEX\t"+"YEAR"+"\n");
                        ta.setText(ta.getText()+"________________________________________________________________________________________________________________________"+"\n");
                                                
                        for(int i=0;i<size;i++){
                            if(sarray.get(i).getname().equals(output)){
                                Student s=sarray.get(i);
                                ta.setText(ta.getText()+s.getname()+"\t"+s.getId()+"\t"+s.getBirthDate()+"\t"+s.getAge()+"\t"+s.getsSex()+"\t"+s.getYear()+"\n");
                            }
                        }
                        }


                        else if(cbs.getSelectedItem().equals("Id"))
                        {
                        int size=sarray.size();
                        String input = null,output;
                        ta.setText(null);
                        ta.setEditable(false);
                        output=JOptionPane.showInputDialog(null,input,"Enter Student Id",JOptionPane.INFORMATION_MESSAGE);
                        ta.setText("NAME\t"+"ID\t"+"DEPARTMENT\t"+"AGE\t"+"SEX\t"+"YEAR"+"\n");
                        ta.setText(ta.getText()+"________________________________________________________________________________________________________________________"+"\n");
                                                
                        for(int i=0;i<size;i++){
                            if(sarray.get(i).getId().equals(output)){
                                Student s=sarray.get(i);
                                ta.setText(ta.getText()+s.getname()+"\t"+s.getId()+"\t"+s.getBirthDate()+"\t"+s.getAge()+"\t"+s.getsSex()+"\t"+s.getYear()+"\n");
                            }
                        }
                        }                   
              }

                });
                  JScrollPane sb=new JScrollPane();
                sb.setBounds(0,0,480,265);
                sb.setViewportView(ta);
                panel.add(sb);
                panel.add(b1);
                panel.add(b2);
                panel.add(b3);
                registerStudent.setVisible(false);
                registerTeacher.setVisible(false);
                registerCourse.setVisible(false);
                display.setVisible(false);
                search.setVisible(true);
 }
 });
 ps.add(ss);
        
 JButton lo=new JButton("LOGOUT");
 lo.setBounds(100,610,100, 30);
 lo.addActionListener(new ActionListener(){
 @Override
 public void actionPerformed(ActionEvent ae){
    CourseManagementSystem cms= new CourseManagementSystem();
     cms.setSize(450, 400);
     cms.setVisible(true);
     setVisible(false);
 }
 });
 add(lo);
 st=new JButton("DISPLAY");
 st.setBounds(20,90, 160, 30);
 st.addActionListener(new ActionListener(){
 @Override
 public void actionPerformed(ActionEvent ae){
     Container panel=display.getContentPane();
     panel.setLayout(null);
     panel.removeAll();
     JButton b1=new JButton("STUDENT");
                b1.setBounds(510,20,100,20);
                JButton b2=new JButton("TEACHER");
                b2.setBounds(510,50,100,20);
                JButton b3=new JButton("COURSE");
                b3.setBounds(510,80,100,20);
                final JTextArea ta=new JTextArea();
                ta.setBounds(0,0,500,300);
                 b3.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        File f=new File("courselist.txt");
                Scanner scan = null;
                try {
                    scan = new Scanner(f);
                } catch (FileNotFoundException ex) {
                }
                ta.setText("COURSE TITLE\t"+"COURSE CODE\t"+"CREDIT HOUR\t"+"DESCRIPTION"+"\n");
                ta.setText(ta.getText()+"_______________________________________________________________________________________"+"\n");
                                        
                while(scan.hasNextLine()){
                    ta.setText(ta.getText()+scan.nextLine()+"\n");
                }

                    }

                });
                   b2.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        File f=new File("teacherlist.txt");
                Scanner scan = null;
                try {
                    scan = new Scanner(f);
                } catch (FileNotFoundException ex) {
                }
                ta.setText("NAME\t"+"ID"+"              "+"ACCADEMIC RANK\t"+"AGE\t"+"SEX\t"+"SALARY"+"\n");
                ta.setText(ta.getText()+"___________________________________________________________________________________________________________________________"+"\n");
                                        
                while(scan.hasNextLine()){
                ta.setText(ta.getText()+scan.nextLine()+"\n");
                }
                    }

                });
                b1.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        File f=new File("studentlist.txt");
                Scanner scan = null;
                try {
                    scan = new Scanner(f);
                } catch (FileNotFoundException ex) {
                }
                ta.setText("NAME\t"+"ID\t"+"BIRTH DATE\t"+"AGE\t"+"SEX\t"+"YEAR"+"\n");
                ta.setText(ta.getText()+"_________________________________________________________________________________________________________________________"+"\n");
                                       
                while(scan.hasNextLine()){
                ta.setText(ta.getText()+scan.nextLine()+"\n");
                }
                    }

                });
                JScrollPane sP=new JScrollPane();
                sP.setBounds(0,0,480,265);
                sP.setViewportView(ta);
                panel.add(sP);
                panel.add(b1);
                panel.add(b2);
                panel.add(b3);
                 registerStudent.setVisible(false);
                registerTeacher.setVisible(false);
                registerCourse.setVisible(false);
                search.setVisible(false);
     display.setVisible(true);
 }
 });
 ps.add(st);
 sc=new JButton("ASSIGN COURSE");
 sc.setBounds(20,150, 160, 30);
 sc.addActionListener(new ActionListener(){
 @Override
 public void actionPerformed(ActionEvent ae){
     Container panel=assign.getContentPane();
     panel.setLayout(null);
     panel.removeAll();
     final JScrollPane sp1=new JScrollPane();
                final JScrollPane sp2=new JScrollPane();
                                sp1.setBounds(10,50,400,300);
                                sp1.setViewportView(liststud);
                                sp2.setBounds(440,50,400,300);
                                sp2.setViewportView(listcourse);
                                panel.add(sp1);
                                panel.add(sp2);
                                final JRadioButton r1=new JRadioButton("SURE?");
                                r1.setBounds(850, 70, 80, 30);
                                final JLabel l6=new JLabel("Teacher List");
                                final JLabel l7=new JLabel("Course  List");
                                final JButton b1=new JButton("ASSIGN");
                                final JButton b2=new JButton("HELP");
                                b2.setBounds(500, 370, 100, 30);
                                b1.setBounds(250,370,200,30);
                                l6.setBounds(100,5,200,30);
                                l7.setBounds(500,5,100,30);
                                panel.add(l6);
                                panel.add(l7);
                                panel.add(b1);
                                panel.add(b2);
                                 b2.addActionListener(new ActionListener(){

                            public void actionPerformed(ActionEvent e) {
                                Help h=new Help();
                                h.setSize(500, 300);
                                h.setLayout(null);
                               // h.setDefaultCloseOperation(3);
                                h.setVisible(true);
                                 }

                });
                            
                                
                                
                                  r1.addActionListener(new ActionListener(){

                            public void actionPerformed(ActionEvent e) {
                                  lmcourse.clear();
                                lmstud.clear();
                                 File f=new File("courselist.txt");
                Scanner s = null;
                try {
                    s = new Scanner(f);
                } catch (FileNotFoundException ex) {
                }
                while(s.hasNext()){
                    lmcourse.addElement(s.next()+","+s.next()+","+s.next()+","+s.next());
                    listcourse.setModel(lmcourse);
                }
                File f1=new File("teacherlist.txt");
                Scanner s1 = null;
                try {
                    s1 = new Scanner(f1);
                } catch (FileNotFoundException ex) {
                }
                while(s1.hasNext()){
                    lmstud.addElement(s1.next()+","+s1.next()+","+s1.next()+","+s1.next()+","+s1.next()+","+s1.next());
                    liststud.setModel(lmstud);
                }
                b1.addActionListener(new ActionListener(){

                                    public void actionPerformed(ActionEvent e) {

                                    }

                });
                                 }

                });
                                  panel.add(r1);
     registerStudent.setVisible(false);
                registerTeacher.setVisible(false);
                registerCourse.setVisible(false);
                search.setVisible(false);
     display.setVisible(false);
     assign.setVisible(true);
 }
 });
 ps.add(sc);
 JButton ab=new JButton("ADD COURSE");
 ab.setBounds(20, 210, 160, 30);
 ab.addActionListener(new ActionListener(){
 @Override
 public void actionPerformed(ActionEvent ae){
     Container panel=add.getContentPane();
     panel.setLayout(null);
     panel.removeAll();
     final JScrollPane sp1=new JScrollPane();
                final JScrollPane sp2=new JScrollPane();
                                sp1.setBounds(10,50,400,300);
                                sp1.setViewportView(liststud);
                                sp2.setBounds(440,50,400,300);
                                sp2.setViewportView(listcourse);
                                panel.add(sp1);
                                panel.add(sp2);
                                 final JRadioButton r2=new JRadioButton("SURE?");
                                r2.setBounds(850, 70, 80, 30);
                                final JLabel l6=new JLabel("Student List");
                                final JLabel l7=new JLabel("Course  List");
                                final JButton b1=new JButton("ADD");
                                final JButton b2=new JButton("HELP");
                                b2.setBounds(500, 370, 100, 30);
                                b1.setBounds(250,370,200,30);
                                l6.setBounds(100,5,200,30);
                                l7.setBounds(500,5,100,30);
                                panel.add(l6);
                                panel.add(l7);
                                panel.add(b1);
                                panel.add(b2);
                                 b2.addActionListener(new ActionListener(){

                            public void actionPerformed(ActionEvent e) {
                                Help1 h=new Help1();
                                h.setSize(500, 300);
                                h.setLayout(null);
                               // h.setDefaultCloseOperation(3);
                                h.setVisible(true);
                                 }

                });
                                 r2.addActionListener(new ActionListener(){

                            public void actionPerformed(ActionEvent e) {
                               lmcourse.clear();
                                lmstud.clear();
                                 File f=new File("courselist.txt");
                Scanner s = null;
                try {
                    s = new Scanner(f);
                } catch (FileNotFoundException ex) {
                }
                while(s.hasNext()){
                    lmcourse.addElement(s.next()+","+s.next()+","+s.next()+","+s.next());
                    listcourse.setModel(lmcourse);
                }
                File f1=new File("studentlist.txt");
                Scanner s1 = null;
                try {
                    s1 = new Scanner(f1);
                } catch (FileNotFoundException ex) {
                }
                while(s1.hasNext()){
                    lmstud.addElement(s1.next()+","+s1.next()+","+s1.next()+","+s1.next()+","+s1.next()+","+s1.next());
                    liststud.setModel(lmstud);
                }

                b1.addActionListener(new ActionListener(){

                                    public void actionPerformed(ActionEvent e) {

                                    }

                });
                                  }

                });
                                  panel.add(r2);
     registerStudent.setVisible(false);
                registerTeacher.setVisible(false);
                registerCourse.setVisible(false);
                search.setVisible(false);
     display.setVisible(false);
     assign.setVisible(false);
     add.setVisible(true);
 }
 });
 ps.add(ab);
 add(ps);
 } 
 
 }

class Student{
    private String name,sex,birthDate,ID,courseName;
    private int year,age;
   public void setName(String Name){
       name=Name;
   }
   public String getname(){
       return name;
   }
   public void setSex(String Sex){
       sex=Sex;
   }
   public String getsSex(){
       return sex;
   }
   public void setBirthDate(String bd){
       birthDate=bd;
   }
   public String getBirthDate(){
       return birthDate;
   }
   public void setId(String id){
       ID=id;
   }
   public String getId(){
       return ID;
   }
   public void setCourseName(String cn){
       courseName=cn;
   }
   public String getCourseName(){
       return courseName;
   }
   public void setYear(int Year){
       year=Year;
   }
   public int getYear(){
       return year;
   }
   public void setAge(int Age){
       age=Age;
   }
   public int getAge(){
       return age;
   }
}
class Teacher{
    private String name,sex,accRank,ID,courseName;
    private int age;
    private double salary;
   public void setName(String Name){
       name=Name;
   }
   public String getName(){
       return name;
   }
   public void setSex(String Sex){
       sex=Sex;
   }
   public String getSex(){
       return sex;
   }
   public void setARank(String aRank){
       accRank=aRank;
   }
   public String getARank(){
       return accRank;
   }
   public void setId(String id){
       ID=id;
   }
   public String getId(){
       return ID;
   }
   public void setCourseName(String cn){
       courseName=cn;
   }
   public String getCourseName(){
       return courseName;
   }
   public void setSalary(Double Salary){
       salary=Salary;
   }
   public double getSalary(){
       return salary;
   }
   public void setAge(int Age){
       age=Age;
   }
   public int getAge(){
       return age;
   }
}
class Course{
    private String title,cCode,cDescription;
    private int creditHour;
   public void setTitle(String Title){
       title=Title;
   }
   public String getTitle(){
       return title;
   }
   public void setCCode(String code){
       cCode=code;
   }
   public String getCCode(){
       return cCode;
   }
   public void setCDescription(String description){
       cDescription=description;
   }
   public String getCDescription(){
       return cDescription;
   }
   public void setCHour(int chour){
       creditHour=chour;
   }
   public int getcHour(){
       return creditHour;
   }
}
